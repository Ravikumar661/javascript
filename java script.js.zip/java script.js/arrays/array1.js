a= [10,20,30,40,50];
console.log("A : " +a);

console.log("A[0] : " +a[0]);
console.log("A[3] : " +a[3]);
console.log("A[6] : " +a[6]);