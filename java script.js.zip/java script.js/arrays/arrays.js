//array creation

a=[10,20,30]
console.log(a)

b=[11,true, 'js']
console.log(b)


c=new Array(101, 202, 303);
console.log(c);