a=[10,20,30,40,50];
console.log("a:"+a);
console.log("length of array a:"+a.length);
for(i=0;i<=a.lenth;i++)
{
    console.log(a[i]);
    for(el of a)
    {
        console.log(el)
    }
}