a= [10,20,30,40,50];
console.log("A : " +a);

console.log("A[0] : " +a[0]);
console.log("A[3] : " +a[3]);
console.log("A[6] : " +a[6]);

a[0]=1001;
console.log("updated a[0]:"+a[0]);
a[5]=5004;
console.log("a[5]:"+a[5]);
a[10]=2004;
console.log("a[10]:"+a[10]);