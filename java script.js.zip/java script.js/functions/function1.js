//this keyword


//regular function
st1 = {
    roll : 101,
    name : 'deep',
    info : function () {
        console.log('regular info function')
        console.log(this.roll+" " + this.name);
        console.log(this);
        //console.log(this.roll + " " + this.name);
    }
}
    st1.info();


    //arrow function
    st2 = {
        roll : 202,
        name : 'pradeep',
        info : () => {
            console.log('regular info function')
            console.log(this.roll+" " + this.name);
            console.log(this);
            //console.log(this.roll + " " + this.name);
        }
    }
        st2.info();
