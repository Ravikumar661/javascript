
/*spread operator allowed
s = (...args) ==>
{
    sum = 0;
    for(i of args){
        sum = sum + i;
    }
    return sum;
}
console.log(S(10,20));
console.log(s2(5,10,25,20));*/




//arguments - not allowed

s2=() =>{
    sum = 0;
    for(i of arguments){
        sum = sum+i;

    }
    return sum;
}
console.log(S(10,20));
console.log(s2(5,10,25,20));



//hosting 

//regular function
function fun(){
    console.log("rugular function executing")
}

//arrow function
arr = () =>{
    console.log("arrow function executing")
}
arr();