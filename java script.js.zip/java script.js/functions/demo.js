//1.no parameter + no return value
function add(){
    num1 = 10
    num2 = 5
    res = num1+num2
    console.log("sum = " + res)
}
add()   //function call



//2.parameter + no return value
function sub(num1, num2){
    res= num1-num2
    console.log("difference =  + res")
}        //function call
sub(50,20)



// 3.parameter +  return value
function mul(num1,num2){
    res = num1*num2
    return res
}
res = mul(20,10)  //function call
console.log("product = " + res)

//4.no parameter + return value
function div(){
    num1 =10
    num2 =3
    res = num1/num2
    return res
}
res = div(20,10)  //function call
console.log("quotient = "+res)