num = 5
for(i=1;i<=10;i++)
{
    console.log(num*i)
}