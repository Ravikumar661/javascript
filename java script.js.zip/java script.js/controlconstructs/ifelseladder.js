marks =85;
if(marks>90){
    console.log("Grade A")
}
else if(marks>74){
    console.log("Grade b")
}
else if(marks>60){
    console.log("Grade c")
}
else
{
    console.log("super star")
}