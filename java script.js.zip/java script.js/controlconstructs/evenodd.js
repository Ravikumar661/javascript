
num =10;
if(num%2 ==0)
    {
    console.log("number is even")
}
else
{
    console.log("number is odd")
}