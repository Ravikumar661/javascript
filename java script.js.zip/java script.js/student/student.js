class Student{
    constructor(roll,name){
        this.roll =roll
        this.name = name
    }
   
    study(){
        console.log("study javascript")
    }
}
st = new Student(101,'Ravi');
console.log(st.roll)
console.log(st.name)
st.study()
st.email= 'Ravi@gmail'
console.log(st.email) 
console.log(st)
delete st.roll
console.log(st)