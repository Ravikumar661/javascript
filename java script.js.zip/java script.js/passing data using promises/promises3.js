//promise chaining
new Promise(
    function(resolve, reject){
        console.log("payment under progress . . .")
        resolve(1599);
    }
).then(
    function(amt){
        console.log("payment recived: + amt");
            return new Promise(
                function(resolve, reject){
                    console.log("delivery under progress . . .");
                    resolve("shirt");
                }
        
        )
    }
).then(
    function(prod){
        console.log("product recived: " + prod)
    }
); 
//action type 
const UPDATE