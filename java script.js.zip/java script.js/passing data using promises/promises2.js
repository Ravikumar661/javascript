new Promise(
    function(resolve,reject){
        console.log("some task");
        
        resolve(
                {
                    username : 'Ravi',
                    email : 'd@k.com',
                    address : 'bengaluru'
                }
        );
     }
).then(
    function(user){
        console.log("Received user info : ");
        console.log(user);
        console.log("user name: " + user.username);
        console.log("email: " + user.email);
        console.log("Address: "+ user.address);
    }
);