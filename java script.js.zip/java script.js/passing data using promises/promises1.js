new Promise(
    function(resolve,reject){
        console.log("some task");
        let data = "Ravi@gmail.com"
        resolve(data);
       }
).then(
    function(data){
        console.log("data recived : " + data);
    }
);