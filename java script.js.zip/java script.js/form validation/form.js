function handleSubmit(){
    let form = document.getElementById('myForm');
    let data = new FormData(form);
    let username = data.get('username');
    let email = data.get('email');
    let password = data.get('password');

    //validating password:5 <= username <= 15
    
    if(username!='')
    {
        if(username.length < 5)
            alert('Too shot- Username should have minimum 5 characters');
        else if(username.length > 12)
            alert('Too long- Username should have maximum 12 characters');
        else    
            alert('Valid username');
    }
    else{
        alert('Please provide a username!')
    }
}

//validating password: 8 <= password <= 15 ,min 1 ->{(a-z),(a-z),(0-9),(_ or @)}
if(password!='')
    {
        if(password.length < 8)
            alert('Too shot- Username should have minimum 5 characters');
        else if(password.length > 15)
            alert('Too long- Username should have maximum 12 characters');
        else    
            alert('Valid username');
    }
    else{
        alert('Please provide a password!')
 }



 
