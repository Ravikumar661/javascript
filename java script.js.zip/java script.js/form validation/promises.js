let pr = new Promise(
    function(resolve,reject){
        setTimeout(
            function(){
                console.log("some async task");
                let task = false;
                if(task = true){
                    resolve();
                }
                else{
                    reject();
            }
       
         }
        ,3000);
      }
);
pr.then(
    function(){
        console.log("task sucess : promise was compleated")
    }
).catch(
    function(){
        console.log("task rejected : promise was rejected")
    }
).finally(
    function(){
        console.log("task was compleated")
    }
);
