/*var a =10;
function fun()
{
    var b =20;
    console.log("fun a = "+a);
    console.log("fun b = "+b);
    onsole.log("fun c = "+c);

}
console.log("a = "+a);
console.log("b = "+b);
console.log("c = "+c);
fun();
var c =30;*/

/*let a =10;
function fun()
{
    var b =20;
    console.log("fun a = "+a);
    console.log("fun b = "+b);
    onsole.log("fun c = "+c);

}
console.log("a = "+a);
console.log("b = "+b);
console.log("c = "+c);
fun();
let c =30;*/


/*const a =10;
function fun()
{
    const b =20;
    console.log("fun a = "+a);
    console.log("fun b = "+b);
    onsole.log("fun c = "+c);

}
console.log("a = "+a);
console.log("b = "+b);
console.log("c = "+c);
fun();
const c =30;*/




a =10;
function fun()
{
     b =20;
    console.log("fun a = "+a);
    console.log("fun b = "+b);
    onsole.log("fun c = "+c);

}
console.log("a = "+a);
console.log("b = "+b);
console.log("c = "+c);
fun();
 c =30;
