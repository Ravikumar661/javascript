/*function outer()
{
    console.log("outer is executing");
    function inner()
    {
        console.log("inner is executing");
    }
    return inner;
}
res = outer();
res();*/


function outer()
{
    var x =10;
    function inner(){
        console.log("x = " + x)
    }
    
    return inner;
}
res = outer();
res();

