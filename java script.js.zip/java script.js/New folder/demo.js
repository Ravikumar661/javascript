st1 = new Object()
st1.roll = 101
st1.name = 'mahesh'
st1.cgpa = 7.5

st2 = {
    roll : 202,
    name : 'ravi',
    cgpa : 8.2

}

function accessStudent(st){
    console.log('roll : '+ st.roll)
    console.log('name : '+ st.name)
    console.log('cgpa : ' + st.cgpa)
}
accessStudent(st1)
accessStudent(st2)