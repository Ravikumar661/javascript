  g = 1
  function addGuest(){
    nuwGuest = document.createElement('li');
    newGuest.textContent = 'Guest' + g;

    glist = document.querySelector('ul');
    glist.appendChild(newGuest);
    g++;
  }
  function removeGuest(){
    glist = document.querySelector('ul');
    lastGuest = glist.lastElementChild;
    glist.removeChild(lastGuest)
    g=g-1;
    
  }