function change(){
    //alert('çhan() is executing')

    container = document.getElementById('container');
    container.style.backgroundColor = 'yellow';

    headings = document.getElementsByClassName('heading');

    //headings.style.color = 'blue';
    for(i=0;i< headings.length;i++){
            headings[i].style.color ='blue';
        }
    //document.getElementsByTagName

    paras = document.getElementsByTagName('p');
    for(i=0;i<paras.length;i++){
        paras[i].style.color = 'brown';
    }
}