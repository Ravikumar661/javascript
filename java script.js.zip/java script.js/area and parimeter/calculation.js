arr = [10,20,25,5,20];

double =arr.map(num => num * 2);
console.log(double);

sq =arr.map(num => num* num);
console.log(sq);



arr = [15,10,25,5,20];
isEven = (num) => num%2 ==0;
even = arr.filter(isEven);
console.log(even);


//sum
arr = [15,10,25,5,20];
sum = function(arr){
    s=0;
    for(i=0;i<arr.length;i++)
    {
        s=s+arr[i];
    }
    return s;
}
console.log(sum(arr));