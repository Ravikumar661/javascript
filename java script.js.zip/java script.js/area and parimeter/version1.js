radArr = [10,20,30,40,50]
function calcArea(radArr){
    areaArr = []
       
    for(i=0 ; i< radArr.length; i++){
        area = 3.14 *radArr[i] * radArr[i];
        areaArr.push(area);
    }
    return areaArr;
}
console.log(calcArea(radArr));



function calcPeri(radArr){
    periArr = []
       
    for(i=0 ; i< radArr.length; i++){
        peri = 2 * 3.14 * radArr[i];
        periArr.push(peri)
    }
    return periArr;
}
console.log(calcArea(radArr));
