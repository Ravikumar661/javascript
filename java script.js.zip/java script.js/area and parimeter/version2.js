radArr = [10,20,30,40,50]

function calculate(radArr, logic)
{
    outputArr = []
    for(i=0;i<radArr.length;i++)
    {
        element = logic(radArr[i]);
        outputArr.push(element);
    }
    return outputArr;
}

area = (rad) => 3.14*rad*rad;

parimeter = (rad =>2*3.14*red);


diameter = (rad) => 2*rad;

console.log(calculate(radArr,area))

console.log(calculate(radArr,parimeter))

console.log(calculate(radArr,diameter))