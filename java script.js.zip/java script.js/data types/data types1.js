a = 10;
console.log('a = ' + a)
console.log(typeof(a));

a = 10.565;
console.log('a = ' +a )
console.log(typeof(a));

a = 'java script is fun';
console.log('a = ' + a)
console.log(typeof(a));

a = true;
console.log('a = ' + a)
console.log(typeof(a));

a = false;
console.log('a = ' + a)
console.log(typeof(a));