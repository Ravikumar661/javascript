a = 10;
console.log('a = ' + a)
console.log(typeof(a));

b = 10.565;
console.log('b = ' + b)
console.log(typeof(b));

c = 'java script is fun';
console.log('c = ' + c)
console.log(typeof(c));

d = 'true';
console.log('d = ' + d)
console.log(typeof(d));

e = 'false';
console.log('e = ' + e)
console.log(typeof(e));