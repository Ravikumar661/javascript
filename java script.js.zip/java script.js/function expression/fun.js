x=function fun(){
    console.log("fun() is executing")
}
x();
y=function(){
    console.log("y function is executing")
}
y();
z= function(name){
    console.log("my name is "+ name);
}
z('deep');