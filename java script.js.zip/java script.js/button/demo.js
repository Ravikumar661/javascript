function fun(){
   alert('fun() is executing')
}

