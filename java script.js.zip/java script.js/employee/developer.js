class Employee{
    constructor()
    {
        this.company = 'kodnest'
    }
    login()
    {
        console.log('login at 10 am')
    }
    task()
    {
        console.log('compleatr your task')
    }
}
    class Developer extends Employee{
        task(){
            console.log('compleate your task')
        }
        develop(){
            console.log('develop an application')
        }
    }
    class Tester extends Employee{
        task(){
            console.log('compleate your testing task')
        }
        test(){
            console.log('test an application')
        }
    }
    dev = new Developer()
    console.log(dev.company)
    dev.login()
    dev.task()
    //dev.develop()

    tes = new Tester()
    console.log(tes.company)
    tes.login()
    tes.task()
    tes.test()

